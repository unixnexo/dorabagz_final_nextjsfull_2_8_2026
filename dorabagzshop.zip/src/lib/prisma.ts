import { PrismaClient } from "@prisma/client";

// Standard Next.js pattern: avoid creating a new PrismaClient on every
// hot-reload in dev (would exhaust DB connections).
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
